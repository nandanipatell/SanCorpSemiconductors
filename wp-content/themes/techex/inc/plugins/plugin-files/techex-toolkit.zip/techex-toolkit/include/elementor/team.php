<?php
namespace TechexToolkit\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Techex Toolkit
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Techex_Toolkit_Team extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'techex_toolkit_team';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Techex Team', 'techex-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'techex-toolkit-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'techex-toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'techex-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		
        $this->start_controls_section(
            'techex_toolkit_layout',
            [
                'label' => esc_html__('Design Layout', 'techex-toolkit'),
            ]
        );

        $this->add_control(
            'techex_toolkit_design_style',
            [
                'label' => esc_html__('Select Layout', 'techex-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'techex-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'member_content',
            [
                'label' => esc_html__('Members', 'techex-toolkit'),
            ]
        );

        $this->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'techex-toolkit' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                      

        $this->add_control(
            'name',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Name', 'techex-toolkit' ),
                'default' => __( 'Jessica Brown', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'name_url',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
                'label' => __( 'Name URL', 'techex-toolkit' ),
                'placeholder' => __( 'Type link here', 'techex-toolkit' ),
                'default' => __( '#', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'techex_toolkit_design_style' => [ 'layout-1' ],
                ],
            ]
        );

        $this->add_control(
            'designation',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
                'label' => __( 'Designation', 'techex-toolkit' ),
                'default' => __( 'Manager', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'web_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Website Address', 'techex-toolkit' ),
                'placeholder' => __( 'Add your profile link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'email_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Email', 'techex-toolkit' ),
                'placeholder' => __( 'Add your email link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );           

        $this->add_control(
            'phone_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Phone', 'techex-toolkit' ),
                'placeholder' => __( 'Add your phone link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'facebook_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Facebook', 'techex-toolkit' ),
                'default' => __( '#', 'techex-toolkit' ),
                'placeholder' => __( 'Add your facebook link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                

        $this->add_control(
            'twitter_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Twitter', 'techex-toolkit' ),
                'default' => __( '#', 'techex-toolkit' ),
                'placeholder' => __( 'Add your twitter link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'instagram_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Instagram', 'techex-toolkit' ),
                'default' => __( '#', 'techex-toolkit' ),
                'placeholder' => __( 'Add your instagram link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );       

        $this->add_control(
            'linkedin_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'LinkedIn', 'techex-toolkit' ),
                'placeholder' => __( 'Add your linkedin link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'youtube_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Youtube', 'techex-toolkit' ),
                'placeholder' => __( 'Add your youtube link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );    

        $this->add_control(
            'flickr_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Flickr', 'techex-toolkit' ),
                'placeholder' => __( 'Add your flickr link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'vimeo_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Vimeo', 'techex-toolkit' ),
                'placeholder' => __( 'Add your vimeo link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'behance_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Behance', 'techex-toolkit' ),
                'placeholder' => __( 'Add your hehance link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'dribble_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Dribbble', 'techex-toolkit' ),
                'placeholder' => __( 'Add your dribbble link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $this->add_control(
            'pinterest_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Pinterest', 'techex-toolkit' ),
                'placeholder' => __( 'Add your pinterest link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'gitub_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Github', 'techex-toolkit' ),
                'placeholder' => __( 'Add your github link', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        ); 
        
        $this->end_controls_section();

        $this->start_controls_section(
			'design_layout_style',
			[
				'label' => __( 'Design Layout', 'techex-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_spacing',
            [
                'label' => __( 'Bottom Spacing', 'techex-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'content_background',
            [
                'label' => __( 'Background', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single' => 'background-color: {{VALUE}}',
                ],
            ]
        );

		$this->add_control(
            'content_background_hover',
            [
                'label' => __( 'Background (Hover)', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .team-one__single-img:before' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .techex-toolkit-team-one__single .title-box',
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'team_member_style',
			[
				'label' => __( 'Members', 'techex-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        // Icon
        $this->add_control(
            '_heading_icon',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Icon', 'techex-toolkit' ),
                'separator' => 'before'
            ]
        );

        $this->start_controls_tabs( 'tabs_icon_style' );

        $this->start_controls_tab(
            'icon_tab',
            [
                'label' => esc_html__( 'Normal', 'techex-toolkit' ),
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'     => esc_html__( 'Text', 'techex-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .social-link a'    => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background',
            [
                'label'     => esc_html__( 'Background', 'techex-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .social-link a' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_border',
				'selector' => '{{WRAPPER}} .techex-toolkit-team-one__single .social-link a',
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'techex-toolkit' ),
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label'     => esc_html__( 'Text', 'techex-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .social-link a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_background_hover',
            [
                'label'     => esc_html__( 'Background', 'techex-toolkit' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .social-link a:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'icon_border_hover',
				'selector' => '{{WRAPPER}} .techex-toolkit-team-one__single .social-link a:hover',
			]
		);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        // Content
        $this->add_control(
            '_heading_content',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Content', 'techex-toolkit' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'member_name_spacing',
            [
                'label' => __( 'Bottom Spacing', 'techex-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .title-box h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'member_name_color',
            [
                'label' => __( 'Name', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .title-box h3 a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'member_name_typography',
                'selector' => '{{WRAPPER}} .techex-toolkit-team-one__single .title-box h3 a',
            ]
        );

        $this->add_responsive_control(
            'member_designation_spacing',
            [
                'label' => __( 'Bottom Spacing', 'techex-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .title-box p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'member_designation_color',
            [
                'label' => __( 'Designation', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .title-box p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'member_designation_typography',
                'selector' => '{{WRAPPER}} .techex-toolkit-team-one__single .title-box p',
            ]
        );


        $this->add_control(
            '_heading_name_layout',
            [
                'label' => esc_html__( 'Layout', 'text-domain' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'member_name_padding',
            [
                'label' => __( 'Padding', 'techex-toolkit' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit-team-one__single .title-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        
        if ( !empty($settings['image']['url']) ) {
            $techex_toolkit_team_image_url = !empty($settings['image']['id']) ? wp_get_attachment_image_url( $settings['image']['id'], 'full') : $settings['image']['url'];
            $techex_toolkit_team_image_alt = get_post_meta($settings["image"]["id"], "_wp_attachment_image_alt", true);
        }  

		?>

            <?php if ( $settings['techex_toolkit_design_style']  == 'layout-1' ): ?>

                <div class="techex-toolkit-team-one__single">
                    <div class="team-one__single-img">
                        <?php if( !empty($techex_toolkit_team_image_url) ) : ?>
                            <img src="<?php echo esc_url($techex_toolkit_team_image_url); ?>" alt="<?php echo esc_attr($techex_toolkit_team_image_alt); ?>">
                        <?php endif; ?>
                        <div class="overlay-content">
                            <div class="social-link">
                                <?php if( !empty($settings['facebook_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['facebook_title'] ); ?>"><i class="fab fa-facebook"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['twitter_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['twitter_title'] ); ?>"><i class="fab fa-twitter"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['pinterest_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['pinterest_title'] ); ?>"><i class="fab fa-pinterest-p"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['instagram_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['instagram_title'] ); ?>"><i class="fab fa-instagram"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['linkedin_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['linkedin_title'] ); ?>"><i class="fab fa-linkedin-in"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['youtube_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['youtube_title'] ); ?>"><i class="fab fa-youtube"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['flickr_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['flickr_title'] ); ?>"><i class="fab fa-flickr"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['vimeo_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['vimeo_title'] ); ?>"><i class="fab fa-vimeo-v"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['behance_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['behance_title'] ); ?>"><i class="fab fa-behance"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['dribble_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['dribble_title'] ); ?>"><i class="fab fa-dribbble"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['phone_title'] ) ) : ?>
                                    <a href="tel:<?php echo esc_url( $settings['phone_title'] ); ?>"><i class="fas fa-phone-alt"></i></a>
                                <?php endif; ?>  

                                <?php if( !empty($settings['gitub_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['gitub_title'] ); ?>"><i class="fab fa-github"></i></a>
                                <?php endif; ?>

                                <?php if( !empty($settings['web_title'] ) ) : ?>
                                    <a href="<?php echo esc_url( $settings['web_title'] ); ?>"><i class="fas fa-globe"></i></a>
                                <?php endif; ?>  

                                <?php if( !empty($settings['email_title'] ) ) : ?>
                                    <a href="mailto:<?php echo esc_url( $settings['email_title'] ); ?>"><i class="fas fa-envelope"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="title-box">
                        <h3><a href="<?php echo esc_url( $settings['name_url'] ); ?>"><?php echo techex_toolkit_kses( $settings['name'] ); ?></a></h3>
                        <?php if( !empty($settings['designation']) ) : ?>
                            <p><?php echo techex_toolkit_kses( $settings['designation'] ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

            <?php elseif ( $settings['techex_toolkit_design_style']  == 'layout-2' ): ?>

            <?php endif; ?>

		<?php
	}
}

$widgets_manager->register( new Techex_Toolkit_Team() );