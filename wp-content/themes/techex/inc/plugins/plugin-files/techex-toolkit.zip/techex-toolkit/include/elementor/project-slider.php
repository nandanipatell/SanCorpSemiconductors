<?php
namespace TechexToolkit\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Techex Toolkit
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Techex_Toolkit_Project_Slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'techex_toolkit_project_slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Project Slider', 'techex-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'techex-toolkit-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'techex_toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'techex-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		
        $this->start_controls_section(
            'techex_toolkit_layout',
            [
                'label' => esc_html__('Design Layout', 'techex-toolkit'),
            ]
        );

        $this->add_control(
            'techex_toolkit_design_style',
            [
                'label' => esc_html__('Select Layout', 'techex-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'techex-toolkit'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'techex_toolkit_project_sliders',
            [
                'label' => esc_html__('Project Slider', 'techex-toolkit'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'techex-toolkit' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                      

        $repeater->add_control(
            'category',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __( 'Project Category', 'techex-toolkit' ),
                'default' => __( 'Business', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
                'label' => __( 'Project Title', 'techex-toolkit' ),
                'default' => __( 'It Solution', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'project_url',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'show_label' => true,
                'label' => __( 'URL', 'techex-toolkit' ),
                'placeholder' => __( 'Type link here', 'techex-toolkit' ),
                'default' => __( '#', 'techex-toolkit' ),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        // REPEATER
        $this->add_control(
            'project_slider_list',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(title || "Carousel Item"); #>',
                'default' => [
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ]
                ]
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'section_layout_style',
			[
				'label' => __( 'Design Layout', 'techex-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'techex-toolkit' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit_project-single .title-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_border_radius',
            [
                'label' => __( 'Content Border Radius', 'techex-toolkit' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit_project-single .title-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'content_background',
            [
                'label' => __( 'Background', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit_project-single .title-box' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
			'content_text_align',
			[
				'label' => esc_html__( 'Alignment', 'techex-toolkit' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'techex-toolkit' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'techex-toolkit' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'techex-toolkit' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
				'selectors' => [
					'{{WRAPPER}} .techex-toolkit_project-single .title-box' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_project_slider_style',
			[
				'label' => __( 'Project Slider', 'techex-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        // Content
        $this->add_control(
            '_heading_content',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Content', 'techex-toolkit' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'project_slider_category_spacing',
            [
                'label' => __( 'Bottom Spacing', 'techex-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit_project-single .title-box p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'project_slider_category_color',
            [
                'label' => __( 'Category', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit_project-single .title-box p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_slider_category_typography',
                'selector' => '{{WRAPPER}} .techex-toolkit_project-single .title-box p',
            ]
        );

        $this->add_control(
            '_heading_title',
            [
                'label' => esc_html__( 'Title', 'text-domain' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'project_slider_title_spacing',
            [
                'label' => __( 'Bottom Spacing', 'techex-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit_project-single .title-box h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'project_slider_title_color',
            [
                'label' => __( 'Color', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit_project-single .title-box h3 a' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_slider_title_typography',
                'selector' => '{{WRAPPER}} .techex-toolkit_project-single .title-box h3 a',
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        if ( !empty($settings['techex_toolkit_project_slider_img_bg']['url']) ) {
            $techex_toolkit_project_slider_img_bg = !empty($settings['techex_toolkit_project_slider_img_bg']['id']) ? wp_get_attachment_image_url( $settings['techex_toolkit_project_slider_img_bg']['id'], 'full' ) : $settings['techex_toolkit_project_slider_img_bg']['url'];
        }

		?>

            <?php if ( $settings['techex_toolkit_design_style']  == 'layout-1' ): ?>

                <div class="techex-toolkit-project-slider">
                    <div class="container-fulid">
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="techex-toolkit_project-slider owl-carousel owl-theme owl-dot-style1">
                                    <?php foreach ( $settings['project_slider_list'] as $item ) :
                                        if ( !empty($item['image']['url']) ) {
                                            $techex_toolkit_project_slider_image_url = !empty($item['image']['id']) ? wp_get_attachment_image_url( $item['image']['id'], 'full') : $item['image']['url'];
                                            $techex_toolkit_project_slider_image_alt = get_post_meta($item["image"]["id"], "_wp_attachment_image_alt", true);
                                        }            
                                        ?>

                                        <div class="techex-toolkit_project-single">
                                            <?php if( !empty($techex_toolkit_project_slider_image_url) ) : ?>
                                                <img src="<?php echo esc_url($techex_toolkit_project_slider_image_url); ?>" alt="<?php echo esc_attr($techex_toolkit_project_slider_image_alt); ?>">
                                            <?php endif; ?>
                                            <div class="overlay-content">
                                                <div class="title-box">
                                                    <p><?php echo techex_toolkit_kses( $item['category'] ); ?></p>
                                                    <?php if( !empty($item['title']) ) : ?>
                                                        <h3><a href="<?php echo esc_url( $item['project_url'] ); ?>"><?php echo techex_toolkit_kses( $item['title'] ); ?></a></h3>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php elseif ( $settings['techex_toolkit_design_style']  == 'layout-2' ): ?>

            <?php endif; ?>

		<?php
	}
}

$widgets_manager->register( new Techex_Toolkit_Project_Slider() );