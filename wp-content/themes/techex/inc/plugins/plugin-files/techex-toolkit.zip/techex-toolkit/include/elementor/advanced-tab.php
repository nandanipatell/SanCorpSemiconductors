<?php
namespace TechexToolkit\Widgets;

use \Elementor\Controls_Manager;
use \Elementor\Widget_Base;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Techex Toolkit
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Techex_Toolkit_Advanced_Tab extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'techex_toolkit_advanced_tab';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Advanced Tab', 'techex-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'techex-toolkit-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'techex_toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'techex-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
            '_section_price_tabs',
            [
                'label' => __('Advanced Tabs', 'techex-toolkit'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
                'label' => __('Title', 'techex-toolkit'),
                'default' => __('Tab Title', 'techex-toolkit'),
                'placeholder' => __('Type Tab Title', 'techex-toolkit'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'active_tab',
            [
                'label' => __('Is Active Tab?', 'techex-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'techex-toolkit'),
                'label_off' => __('No', 'techex-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
                'frontend_available' => true,
            ]
        );

        $repeater->add_control(
            'template',
            [
                'label' => __('Section Template', 'techex-toolkit'),
                'placeholder' => __('Select a section template for as tab content', 'techex-toolkit'),
  
                'type' => Controls_Manager::SELECT2,
                'options' => get_elementor_templates()
            ]
        );

        $this->add_control(
            'tabs',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{title}}',
                'default' => [
                    [
                        'title' => 'Tab 1',
                    ],
                    [
                        'title' => 'Tab 2',
                    ]
                ]
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'techex-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .tab-one__tabs .tab-buttons li',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'text-domain' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', ],
				'selectors' => [
					'{{WRAPPER}} .tab-one__tabs .tab-buttons li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'padding',
			[
				'label' => esc_html__( 'Padding', 'text-domain' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', ],
				'selectors' => [
					'{{WRAPPER}} .tab-one__tabs .tab-buttons li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'margin',
			[
				'label' => esc_html__( 'Margin', 'text-domain' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', ],
				'selectors' => [
					'{{WRAPPER}} .tab-one__tabs .tab-buttons li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'advanced_color_tabs' );
		
		$this->start_controls_tab(
			'_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'text-domain' ),
			]
		);
		
		$this->add_control(
			'color',
			[
				'label' => esc_html__( 'Color', 'text-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tab-one__tabs .tab-buttons li' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'background_color',
			[
				'label' => esc_html__( 'Background', 'text-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tab-one__tabs .tab-buttons li' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'text-domain' ),
			]
		);
		
		$this->add_control(
			'color_hover',
			[
				'label' => esc_html__( 'Color', 'text-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tab-one__tabs .tab-buttons li:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'background_color_hover',
			[
				'label' => esc_html__( 'Background', 'text-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tab-one__tabs .tab-buttons li:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'_active_tab',
			[
				'label' => esc_html__( 'Active', 'text-domain' ),
			]
		);
		
		$this->add_control(
			'color_active',
			[
				'label' => esc_html__( 'Color', 'text-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tab-one__tabs .tab-buttons li.active-btn' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'background_color_active',
			[
				'label' => esc_html__( 'Background', 'text-domain' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tab-one__tabs .tab-buttons li.active-btn' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>


            <div class="tab-one__tabs tabs-box">
                <ul class="tab-buttons clearfix">
                    <?php foreach ($settings['tabs'] as $key => $tab):
                        $active = ($key == 0) ? 'active-btn' : '';
                    ?>
                        <li data-tab="#<?php echo esc_attr($key); ?>" class="tab-btn <?php echo esc_attr($active); ?>"><span><?php echo techex_toolkit_kses($tab['title']); ?></span></li>
	                <?php endforeach; ?>
                </ul>
                <div class="tabs-content">
                    <?php foreach ($settings['tabs'] as $key => $tab):
                        $active = ($key == 0) ? 'active-tab' : '';
                    ?>
	                <div class="tab <?php echo esc_attr($active); ?>" id="<?php echo esc_attr($key); ?>">
                        <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content($tab['template'], true); ?>
                    </div>
	                <?php endforeach; ?>
                </div>
            </div>

		<?php
	}

}
$widgets_manager->register( new Techex_Toolkit_Advanced_Tab() );