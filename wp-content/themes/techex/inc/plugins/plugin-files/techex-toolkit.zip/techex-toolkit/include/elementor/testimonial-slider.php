<?php
namespace TechexToolkit\Widgets;

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Techex Toolkit
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Techex_Toolkit_Testimonial_Slider extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'techex_toolkit_testimonial_slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Testimonial Slider', 'techex-toolkit' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'techex-toolkit-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'techex_toolkit' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'techex-toolkit' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'techex_toolkit_section_title',
            [
                'label' => esc_html__( 'Title & Content', 'techex-toolkit' ),
            ]
        );

        $this->add_control(
            'techex_toolkit_design_style',
            [
                'label' => esc_html__( 'Style', 'techex-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'layout-1',
                'options' => [
                    'layout-1' => esc_html__( 'Layout 1', 'techex-toolkit' ),
                ],
            ]
        );
        
        $this->end_controls_section();

        // Testimonial List
        $this->start_controls_section(
            'testimonial_list_content',
            [
                'label' => esc_html__( 'Testimonial List', 'techex-toolkit' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'testimonial_image',
            [
                'label' => esc_html__( 'Testimonial Image', 'techex-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'testimonial_name', [
                'label' => esc_html__( 'Name', 'techex-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Rashal Khan' , 'techex-toolkit' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'testimonial_position', [
                'label' => esc_html__( 'Position', 'techex-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'Founder' , 'techex-toolkit' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'testimonial_description',
            [
                'label' => esc_html__( 'Description', 'techex-toolkit' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 10,
                'default' => esc_html__( 'Hiring managers are busy people, so you need to make yourout the crowd as quickly as possible. In the first section. This should headline achievements', 'techex-toolkit' ),
            ]
        );

        $repeater->add_control(
            'show_rating',
            [
                'label' => esc_html__( 'Star Rating', 'techex-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'techex-toolkit' ),
                'label_off' => esc_html__( 'Hide', 'techex-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater->add_control(
			'techex_toolkit_star_rating',
			[
				'label'                 => esc_html__( 'Star Rating', 'techex-toolkit' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'four-star',
				'options' => [
					'one-star'          => esc_html__( 'One', 'techex-toolkit' ),
					'two-star'          => esc_html__( 'Two', 'techex-toolkit' ),
					'three-star'        => esc_html__( 'Three', 'techex-toolkit' ),
					'four-star'         => esc_html__( 'Four', 'techex-toolkit' ),
					'five-star'         => esc_html__( 'Five', 'techex-toolkit' ),
                ],
			]
        );

        $this->add_control(
            'testimonial_list',
            [
                'label' => esc_html__( 'Testimonial List', 'techex-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' =>  $repeater->get_controls(),
                'default' => [
                    [
                        'testimonial_name' => esc_html__( 'Michael Brown', 'techex-toolkit' ),
                        'testimonial_position' => esc_html__( 'Online Entrepreneur', 'techex-toolkit' ),
                        'testimonial_description' => esc_html__( '“Ive been using this web hosting service for a few months and its been nothing but problems. My website has gone down multiple times and the customer service has been unresponsive. I would not recommend this company."', 'techex-toolkit' ),
                    ],
                    [
                        'testimonial_name' => esc_html__( 'Michael Brown', 'techex-toolkit' ),
                        'testimonial_position' => esc_html__( 'Online Entrepreneur', 'techex-toolkit' ),
                        'testimonial_description' => esc_html__( '“Ive been using this web hosting service for a few months and its been nothing but problems. My website has gone down multiple times and the customer service has been unresponsive. I would not recommend this company."', 'techex-toolkit' ),
                    ],
                    [
                        'testimonial_name' => esc_html__( 'Matthew Walker', 'techex-toolkit' ),
                        'testimonial_position' => esc_html__( 'Online Entrepreneur', 'techex-toolkit' ),
                        'testimonial_description' => esc_html__( '“Ive been using this web hosting service for a few months and its been nothing but problems. My website has gone down multiple times and the customer service has been unresponsive. I would not recommend this company."', 'techex-toolkit' ),
                    ],
                    [
                        'testimonial_name' => esc_html__( 'Logan Martin', 'techex-toolkit' ),
                        'testimonial_position' => esc_html__( 'Online Entrepreneur', 'techex-toolkit' ),
                        'testimonial_description' => esc_html__( '“Ive been using this web hosting service for a few months and its been nothing but problems. My website has gone down multiple times and the customer service has been unresponsive. I would not recommend this company."', 'techex-toolkit' ),
                    ],
                    [
                        'testimonial_name' => esc_html__( 'Julian Baker', 'techex-toolkit' ),
                        'testimonial_position' => esc_html__( 'Online Entrepreneur', 'techex-toolkit' ),
                        'testimonial_description' => esc_html__( '“Ive been using this web hosting service for a few months and its been nothing but problems. My website has gone down multiple times and the customer service has been unresponsive. I would not recommend this company."', 'techex-toolkit' ),
                    ],

                ],
                'title_field' => '{{{ testimonial_name }}}',
            ]
        );

        $this->end_controls_section();

        // TAB_STYLE
		$this->start_controls_section(
			'techex_toolkit_testimonial_layout_style',
			[
				'label' => __( 'Layout', 'techex-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'content_padding',
            [
                'label' => __( 'Content Padding', 'techex-toolkit' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_responsive_control(
            'content_border_radius',
            [
                'label' => __( 'Content Border Radius', 'techex-toolkit' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .owl-item.active.center' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_background',
            [
                'label' => esc_html__( 'Background', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_layout_style' );

        $this->start_controls_tab(
            'layout_tab',
            [
                'label' => esc_html__( 'Normal', 'techex-toolkit' ),
            ]
        );

        $this->add_control(
            'content_dots',
            [
                'label' => __( 'Dots', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .owl-dots button span' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'layout_hover_tab',
            [
                'label' => esc_html__( 'Hover', 'techex-toolkit' ),
            ]
        );

        $this->add_control(
            'content_dots_hover',
            [
                'label' => __( 'Dots', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .owl-dots .owl-dot.active span' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .owl-dots .owl-dot:hover span' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

		$this->end_controls_section();

        $this->start_controls_section(
			'techex_toolkit_testimonial_list_style',
			[
				'label' => __( 'Testimonial List', 'techex-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        // Name
        $this->add_control(
            '_heading_name',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Name', 'techex-toolkit' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'name_spacing',
            [
                'label' => __( 'Bottom Spacing', 'techex-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single .client-info .text h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label' => __( 'Color', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single .client-info .text h2' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'name_typography',
                'selector' => '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single .client-info .text h2',
            ]
        );

        // Position
        $this->add_control(
            '_heading_position',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Position', 'techex-toolkit' ),
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'position_color',
            [
                'label' => __( 'Color', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single .client-info .text p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'position_typography',
                'selector' => '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single .client-info .text p',
            ]
        );

        // Description
        $this->add_control(
            '_content_description',
            [
                'type' => Controls_Manager::HEADING,
                'label' => __( 'Description', 'techex-toolkit' ),
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control(
            'description_spacing',
            [
                'label' => __( 'Bottom Spacing', 'techex-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single .testimonials-one__single-text p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __( 'Color', 'techex-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single .testimonials-one__single-text p' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .techex-toolkit.testimonials-one__carousel .testimonials-one__single .testimonials-one__single-text p',
            ]
        );

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        
		?>

        <?php if ( $settings['techex_toolkit_design_style']  == 'layout-1' ): ?>
            <section class="testimonials-one">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="techex-toolkit testimonials-one__carousel owl-carousel owl-theme owl-dot-style1">
                                <?php foreach ($settings['testimonial_list'] as $index => $item) : 
                                    if ( !empty($item['testimonial_image']['url']) ) {
                                        $techex_toolkit_testimonial_image = !empty($item['testimonial_image']['id']) ? wp_get_attachment_image_url( $item['testimonial_image']['id']) : $item['testimonial_image']['url'];
                                        $techex_toolkit_testimonial_image_alt = get_post_meta($item["testimonial_image"]["id"], "_wp_attachment_image_alt", true);
                                    }
                                ?>
                                <div class="testimonials-one__single">
                                    <div class="testimonials-one__single-icon">
                                        <span class="icon-left-quote"></span>
                                    </div>
                                    <?php if ( !empty($item['testimonial_description']) ) : ?>
                                        <div class="testimonials-one__single-text">
                                            <p><?php echo techex_toolkit_kses($item['testimonial_description']); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ( 'yes' === $item['show_rating'] ) : ?>
                                        <div class="rating twinkle-star-rating <?php esc_attr_e( $item['techex_toolkit_star_rating'] ); ?>">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div class="client-info">
                                        <?php if ( !empty($techex_toolkit_testimonial_image) ) : ?>
                                            <div class="img">
                                                <img src="<?php echo esc_url($techex_toolkit_testimonial_image); ?>" alt="<?php echo esc_url($techex_toolkit_testimonial_image_alt); ?>">
                                            </div>
                                        <?php endif; ?>
                                        <div class="text">
                                            <?php if ( !empty($item['testimonial_name']) ) : ?> 
                                                <h2><?php echo techex_toolkit_kses($item['testimonial_name']); ?></h2>
                                            <?php endif; ?>
                                            <?php if ( !empty($item['testimonial_position']) ) : ?>
                                                <p><?php echo techex_toolkit_kses($item['testimonial_position']); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        
        <?php elseif ( $settings['techex_toolkit_design_style']  == 'layout-2' ): ?>

        <?php endif; ?>

        <?php 
	}
}

$widgets_manager->register( new Techex_Toolkit_Testimonial_Slider() );