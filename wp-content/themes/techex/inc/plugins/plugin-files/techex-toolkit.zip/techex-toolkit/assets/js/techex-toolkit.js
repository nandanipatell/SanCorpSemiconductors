(function($) {
    "use strict";

    function Techex_Toolkit_AdvancedTab() {

        if ($(".tabs-box").length) {
            $(".tabs-box .tab-buttons .tab-btn").on("click", function(e) {
                e.preventDefault();
                var target = $($(this).attr("data-tab"));

                if ($(target).is(":visible")) {
                    return false;
                } else {
                    target
                        .parents(".tabs-box")
                        .find(".tab-buttons")
                        .find(".tab-btn")
                        .removeClass("active-btn");
                    $(this).addClass("active-btn");
                    target
                        .parents(".tabs-box")
                        .find(".tabs-content")
                        .find(".tab")
                        .fadeOut(0);
                    target
                        .parents(".tabs-box")
                        .find(".tabs-content")
                        .find(".tab")
                        .removeClass("active-tab");
                    $(target).fadeIn(300);
                    $(target).addClass("active-tab");
                }
            });
        }
    }

    function Techex_Toolkit_Testimonial_Slider() {
        if ($(".testimonials-one__carousel").length) {
            $(".testimonials-one__carousel").owlCarousel({
                loop: true,
                center: true,
                margin: 30,
                nav: false,
                smartSpeed: 500,
                autoHeight: false,
                autoplay: true,
                dots: true,
                autoplayTimeout: 10000,
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    800: {
                        items: 2
                    },
                    1024: {
                        items: 2
                    },
                    1200: {
                        items: 3
                    }
                }
            });
        }
    }

    function Techex_Toolkit_Project_Slider() {
        if ($(".techex-toolkit_project-slider").length) {
            $(".techex-toolkit_project-slider").owlCarousel({
                loop: true,
                margin: 0,
                nav: false,
                smartSpeed: 500,
                autoHeight: false,
                autoplay: true,
                dots: false,
                autoplayTimeout: 10000,
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    800: {
                        items: 2
                    },
                    1024: {
                        items: 2
                    },
                    1200: {
                        items: 3
                    }
                }
            });
        }
    }

    $(window).on("elementor/frontend/init", function() {
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/techex_toolkit_advanced_tab.default", Techex_Toolkit_AdvancedTab
        );
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/techex_toolkit_testimonial_slider.default", Techex_Toolkit_Testimonial_Slider
        );
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/techex_toolkit_project_slider.default", Techex_Toolkit_Project_Slider
        );
    });

}(jQuery));