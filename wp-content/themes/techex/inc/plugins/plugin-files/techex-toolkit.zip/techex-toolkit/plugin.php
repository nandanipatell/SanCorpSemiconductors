<?php
namespace TechexToolkit;

use TechexToolkit\PageSettings\Page_Settings;
use Elementor\Controls_Manager;


/**
 * Class Plugin
 *
 * Main Plugin class
 * @since 1.2.0
 */
class Techex_Toolkit_Plugin {

	/**
	 * Instance
	 *
	 * @since 1.2.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.2.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Add Category
	 */

    public function techex_toolkit_elementor_category($manager)
    {
        $manager->add_category(
            'techex_toolkit',
            array(
                'title' => esc_html__('Techex Toolkit', 'techex-toolkit'),
                'icon' => 'eicon-banner',
            )
        );
    }

	/**
	 * Frontend widget_styles
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function frontend_widgets_styles() {
		wp_enqueue_style('techex-toolkit', TECHEX_TOOLKIT_ADDONS_URL . 'assets/css/techex-toolkit.css', null, '1.0');
	}

	/**
	 * Frontend widget_scripts
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function frontend_widgets_scripts() {
		wp_enqueue_script( 'techex-toolkit', plugins_url( '/assets/js/techex-toolkit.js', __FILE__ ), [ 'jquery' ], false, true );
	}

	/**
	 * Editor scripts
	 *
	 * Enqueue plugin javascripts integrations for Elementor editor.
	 *
	 * @since 1.2.1
	 * @access public
	 */
	public function editor_widgets_scripts() {
		add_filter( 'script_loader_tag', [ $this, 'editor_scripts_as_a_module' ], 10, 2 );
		wp_enqueue_script( 'techex-toolkit-editor', plugins_url( '/assets/js/techex-toolkit.js', __FILE__ ), [ 'elementor-editor', ], '1.2.1', true );
	}

	/**
	 * Editor widget_styles
	 */
    function editor_widgets_styles() {
        wp_enqueue_style('techex-toolkit-editor', TECHEX_TOOLKIT_ADDONS_URL . 'assets/css/editor.css', null, '1.0');
    }

	/**
	 * Force load editor script as a module
	 *
	 * @since 1.2.1
	 *
	 * @param string $tag
	 * @param string $handle
	 *
	 * @return string
	 */
	public function editor_scripts_as_a_module( $tag, $handle ) {
		if ( 'techex-toolkit-editor' === $handle ) {
			$tag = str_replace( '<script', '<script type="module"', $tag );
		}

		return $tag;
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.2.0
	 * @access public
	 *
	 * @param Widgets_Manager $widgets_manager Elementor widgets manager.
	 */
	public function register_widgets( $widgets_manager ) {
		// Its is now safe to include Widgets files
		foreach($this->techex_toolkit_widget_list() as $widget_file_name){
			require_once( TECHEX_TOOLKIT_ELEMENTS_PATH . "/{$widget_file_name}.php" );
		}
	}

	public function techex_toolkit_widget_list() {
		return [
			'advanced-tab',
			'testimonial-slider',
			'team',
			'project-slider',
		];
	}

	/**
	 * Add page settings controls
	 *
	 * Register new settings for a document page settings.
	 *
	 * @since 1.2.1
	 * @access private
	 */
	private function add_page_settings_controls() {
		require_once( __DIR__ . '/page-settings/manager.php' );
		new Page_Settings();
	}

	/**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function __construct() {

        add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'frontend_widgets_styles' ] );
        add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'frontend_widgets_scripts' ] );
	    add_action('elementor/editor/after_enqueue_styles', [$this, 'editor_widgets_styles'] );
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'editor_widgets_scripts' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
		add_action('elementor/elements/categories_registered', [$this, 'techex_toolkit_elementor_category']);

		$this->add_page_settings_controls();

	}
}

// Instantiate Plugin Class
Techex_Toolkit_Plugin::instance();